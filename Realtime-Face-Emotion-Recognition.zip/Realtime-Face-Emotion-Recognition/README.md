# Realtime-Face-Emotion-Recognition
This project aims to predict Realtime Emotion of Human Face and it is developed using Computer Vision. In this project, We have trained a large dataset to get most accurate face emotion of human face. This project is designed with great Graphical User Interface . HOPE YOU ENJOY THIS !!!!
