# EmotionDetection-using-NLP

This web app uses a language model from Hugging Face to analyze the sentiments in product reviews (provided as a .csv file) and allows users to analyze customer reviews in the form of a pie chart. The "Word Cloud" page provides high-frequency words in the reviews, allowing the user to analyze the cause of the sentiment.

![image](https://github.com/RohitNegi12/EmotionDetection-using-NLP/assets/128612679/c9c404df-8f4e-4dbb-b2a6-013dfcb892ea)

![image](https://github.com/RohitNegi12/EmotionDetection-using-NLP/assets/128612679/132422ab-8498-466e-b779-63d836aa93ab)
