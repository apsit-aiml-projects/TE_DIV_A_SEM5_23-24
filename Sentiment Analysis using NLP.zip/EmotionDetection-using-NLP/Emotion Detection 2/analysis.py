from typing import TextIO
import pandas as pd
import numpy as np
import jsonpickle
import pickle

from transformers import AutoTokenizer
from transformers import TFAutoModelForSequenceClassification
from scipy.special import softmax
from wordcloud import WordCloud
from hindi_model import model_predict

# Server

from flask import Flask, request, Response
from markupsafe import escape

# Pretrained Model

# MODEL = f"cardiffnlp/twitter-roberta-base-sentiment"
# tokenizer = AutoTokenizer.from_pretrained(MODEL)
# model = TFAutoModelForSequenceClassification.from_pretrained(MODEL)

def preprocess(text: str) -> str:
    new_text = []

    for t in text.split(" "):
        t = "@user" if t.startswith("@") and len(t) > 1 else t
        t = "http" if t.startswith("http") else t
        
    return " ".join(new_text)


# def roberta_analyze(sentence: str) -> np.ndarray:
#     processed_sentence = preprocess(sentence)
#     encoded_text = tokenizer(
#         processed_sentence, return_tensors="tf", truncation=True, max_length=50
#     )
#     output = model(**encoded_text)
#     scores = output[0][0].numpy()
#     scores = softmax(scores).tolist()
#     return scores


def getScores(data_file: TextIO) -> dict[str, list[float]]:
    df = pd.read_csv(data_file, escapechar="\\", skipinitialspace=True)
    df.sort_values(by="product_id", inplace=True)
    df.set_index(keys=["product_id"], drop=False, inplace=True)
    products = df["product_id"].unique().tolist()
    result: dict[str, list[float]] = {}
    for product in products:
        prod_df = df.loc[df["product_id"] == product]
        scores = [0, 0] # Index 0 = Negative, 1 = Positive
        for _, row in prod_df.iterrows():
            emotion = int(model_predict(row["review"]))
            scores[emotion] += 1
        # scores = np.average(scores, axis=0)
        result[product] = scores
    print(result)
    return result


def make_wc(testcsv: TextIO) -> dict[str, WordCloud]:
    df = pd.read_csv(testcsv, escapechar="\\", skipinitialspace=True, encoding='utf-8')
    df.sort_values(by="product_id", inplace=True)
    df.set_index(keys=["product_id"], drop=False, inplace=True)
    products = df["product_id"].unique().tolist()
    result: dict[str, WordCloud] = {}

    for product in products:
        prod_df = df.loc[df["product_id"] == product]
        text = " ".join(prod_df["review"])

        with open("Emotion Detection 2/tagger.pkl", "rb") as f:
            tagger = pickle.load(f)
        with open("Emotion Detection 2/stopwords.pkl", "rb") as f:
            stopwords = pickle.load(f)

        def remove_stopwords(txt: str) -> str:
            return " ".join([word for word in txt.split() if word not in stopwords])
        text = remove_stopwords(text)
        text = " ".join([i for i in text.split() if tagger.get(i, "Unk") == 'a'])

        # Generate word frequencies from text
        freq = {}
        for word in set(text.split()):
            freq[word] = text.count(word)

        wc = WordCloud(width=800, height=400, font_path="Emotion Detection 2/NotoSansDevanagari.ttf").generate_from_frequencies(freq)
        result["{}".format(product)] = wc
    return result


# Server Code
app = Flask(__name__)


@app.route("/")
def hello():
    return "Hello, World!"


@app.route("/scores", methods=["GET"])
def greet():
    uploaded_file = request.files["review_data"]
    data_file = uploaded_file.read()  # Bytes
    with open("test_file.csv", "wb") as test_file:
        test_file.write(data_file)

    with open("test_file.csv", "r", encoding='utf-8') as test_file:
        wc_data = make_wc(test_file)

    with open("test_file.csv", "r", encoding='utf-8') as test_file:
        res_scores = getScores(test_file)

    res_content = jsonpickle.encode((res_scores, wc_data))

    res = Response(content_type="application/octet-stream", response=res_content)

    return res


if __name__ == "__main__":
    app.run(debug=True)
