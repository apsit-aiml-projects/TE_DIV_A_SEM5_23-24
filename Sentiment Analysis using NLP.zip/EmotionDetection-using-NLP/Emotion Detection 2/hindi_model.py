import pickle
from gensim.models import Word2Vec
import numpy as np
import xgboost
import tensorflow as tf
from tensorflow.keras.preprocessing.sequence import pad_sequences

prefix = "Emotion Detection 2/"
# prefix = ""

# with open(f"{prefix}xgboost_model.pkl", "rb") as f:
#     model = pickle.load(f)

model = tf.keras.models.load_model(f"{prefix}emotionDetection_new.keras")

with open(f"{prefix}tokenizer_new.pkl", "rb") as t:
    tokenizer = pickle.load(t)

def sent_vectorized(sentence: list[str]):
    sequences = tokenizer.texts_to_sequences(sentence)
    padded_sequences=pad_sequences(sequences,maxlen=40,padding='post',truncating='post')
    return padded_sequences
    # wv_res=np.zeros(tokenizer.wv.vector_size)
    # ctr=1
    # for word in sentence:
    #     if word in tokenizer.wv:
    #         ctr +=1
    #         wv_res+=tokenizer.wv[word]
    # wv_res=wv_res/ctr
    # return wv_res

def model_predict(txt: str):
    res = model.predict(sent_vectorized([txt]))
    return np.argmax(res)